const app = require("./app");
const sequelize = require("./config/database");

const PORT = process.env.PORT || 5000;

app.listen(PORT, async () => {
  try {
    await sequelize.sync();
    console.log(`🚀 Server đang chạy tại http://localhost:${PORT}`);
  } catch (error) {
    console.error("❌ Lỗi khi đồng bộ database:", error);
  }
});