import { useState, useEffect } from "react";
import { createCategory, updateCategory } from "../api/categoryApi";

const CategoryForm = ({ selectedCategory, onSuccess }) => {
  const [name, setName] = useState("");

  useEffect(() => {
    if (selectedCategory) {
      setName(selectedCategory.name);
    } else {
      setName("");
    }
  }, [selectedCategory]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (selectedCategory) {
      await updateCategory(selectedCategory.id, name);
    } else {
      await createCategory(name);
    }
    onSuccess();
  };

  return (
    <form onSubmit={handleSubmit}>
      <h2>{selectedCategory ? "Cập nhật danh mục" : "Thêm danh mục"}</h2>
      <input value={name} onChange={(e) => setName(e.target.value)} required />
      <button type="submit">{selectedCategory ? "Cập nhật" : "Thêm"}</button>
    </form>
  );
};

export default CategoryForm;