import { useEffect, useState } from "react";
import { getCategories, deleteCategory } from "../api/categoryApi";

const CategoryList = ({ onEdit }) => {
  const [categories, setCategories] = useState([]);

  useEffect(() => {
    loadCategories();
  }, []);

  const loadCategories = async () => {
    const data = await getCategories();
    setCategories(data);
  };

  const handleDelete = async (id) => {
    await deleteCategory(id);
    loadCategories();
  };

  return (
    <div>
      <h2>Danh sách danh mục</h2>
      <ul>
        {categories.map((cat) => (
          <li key={cat.id}>
            {cat.name} 
            <button onClick={() => onEdit(cat)}>Sửa</button>
            <button onClick={() => handleDelete(cat.id)}>Xóa</button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default CategoryList;