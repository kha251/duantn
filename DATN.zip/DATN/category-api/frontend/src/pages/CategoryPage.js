import { useState } from "react";
import CategoryList from "../components/CategoryList";
import CategoryForm from "../components/CategoryForm";

const CategoryPage = () => {
  const [selectedCategory, setSelectedCategory] = useState(null);

  return (
    <div>
      <CategoryForm 
        selectedCategory={selectedCategory} 
        onSuccess={() => setSelectedCategory(null)}
      />
      <CategoryList onEdit={setSelectedCategory} />
    </div>
  );
};

export default CategoryPage;